<?php
//Hi Baby :)
header("Location: http://goo.gl/1GEK64");
?>